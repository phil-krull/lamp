<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>User Dashboard</title>
</head>
<body>
  <a href="/dashboard">Return to Dashboard</a>
  <form action="/sessions/destroy" method="post">
    <input type="submit" value="Logout">
  </form>
  <h3>Edit Profile</h3>
  <fieldset>
    <legend>Edit Information</legend>
    <form action="/admins/update/<?= $user['id'] ?>" method="post">
      <label>First Name:</label>
      <input type="text" name="first_name" value="<?= $user['first_name'] ?>">
      <label>Last Name:</label>
      <input type="text" name="last_name" value="<?= $user['last_name'] ?>">
      <label>Email:</label>
      <input type="email" name="email" value="<?= $user['email'] ?>">
      <label>User Level:</label>
      <select name="user_level">
        <option selected disabled>Choose a level</option>
        <option>Normal</option>
        <option>Admin</option>
      </select>
      <input type="submit" value="Save">
    </form>
  </fieldset>
  <fieldset>
    <legend>Change Password</legend>
    <form action="/users/password_update/<?= $user['id'] ?>" method="post">
      <label>Password:</label>
      <input type="password" name="password">
      <label>Confirm Password:</label>
      <input type="password" name="password_confirmation">
      <input type="submit" value="Update Password">
    </form>
  </fieldset>
  <? if ($this->session->flashdata('errors')) { ?>
    <?= $this->session->flashdata('errors') ?>
  <? } ?>
</body>
</html>