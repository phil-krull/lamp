<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>User Dashboard</title>
</head>
<body>
  <a href="/users/edit">Profile</a> | 
  <a href="/dashboard">Dashboard</a>
  <form action="/sessions/destroy" method="post">
    <input type="submit" value="Logout">
  </form>
  <h3><?= $user['first_name'] ?> <?= $user['last_name'] ?></h3>
  <table>
    <tr>
      <td>Registered at:</td>
      <td><?= date("M d, Y", strtotime($user['created_at'])) ?></td>
    </tr>
    <tr>
      <td>User ID:</td>
      <td><?= $user['id'] ?></td>
    </tr>
    <tr>
      <td>Email address:</td>
      <td><?= $user['email'] ?></td>
    </tr>
    <tr>
      <td>Description:</td>
      <td><?= $user['description'] ?></td>
    </tr>
  </table>
  <h3>Leave a message for <?= $user['first_name'] ?></h3>
  <form action="/messages/<?= $user['id'] ?>" method="post">
    <textarea name="content"></textarea>
    <input type="submit" value="Post">
  </form>
  <?php if($messages) { ?>
    <?php foreach ($messages as $key => $value) { ?>
      <p><?= $value['messager_first_name'] ?> <?= $value['messager_last_name'] ?> wrote:</p>
      <p><?= date("M d, Y", strtotime($user['created_at'])) ?></p>
      <ul><?= $value['message_content'] ?>
        <ul>
      <?php if($posts) { ?>
        <?php for($idx = 0; $idx < sizeof($posts); $idx++) { ?>
          <?php foreach ($posts[$idx] as $key => $value2) { ?>
            <?php if($value2['message_id'] == $value['id']) { ?> 
              <p><?= $value2['first_name'] ?> <?= $value2['last_name'] ?> wrote:</p>
              <p><?= date("M d, Y", strtotime($value2['created_at'])) ?></p>
              <ul><?= $value2['content'] ?></ul>
            <?php } ?>
          <?php } ?>
        <?php } ?>
      <?php } ?>
      </ul>
      <form action="/posts/<?= $value['id'] ?>/<?= $value['message_user_id'] ?>" method="post">
        <textarea name="content"></textarea>
        <input type="submit" value="Post">
      </form>
      </ul>
     <?php } ?>
  <?php } ?>
</body>
</html>