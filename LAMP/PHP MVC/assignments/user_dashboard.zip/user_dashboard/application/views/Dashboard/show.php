<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>User Dashboard</title>
</head>
<body>
  <a href="/users/edit">Profile</a>
  <form action="/sessions/destroy" method="post">
    <input type="submit" value="Logout">
  </form>
  <h3>All Users</h3>
<table>
    <tr>
      <td>ID</td>
      <td>Name</td>
      <td>Email</td>
      <td>Register Date</td>
      <td>User Level</td>
    </tr>
    <?php foreach($users as $key => $value) { ?>
    <tr>
      <td><?= $value['id'] ?></td>
      <td><a href="/users/show/<?= $value['id'] ?>"><?= $value['first_name'] ?> <?= $value['last_name'] ?></a></td>
      <td><?= $value['email'] ?></td>
      <td><?= date("M d, Y", strtotime($value['created_at'])) ?></td>
      <td><?= $value['user_level'] ?></td>
    </tr>
   <?php } ?>
  </table>
  <? if ($this->session->flashdata('errors')) { ?>
    <?= $this->session->flashdata('errors') ?>
  <? } ?>
</body>
</html>