<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>User Dashboard</title>
</head>
<body>
  <h1>Home page</h1>
  <a href="/login">Already have an account? Login</a> | <a href="/register">Don't have an account? Register</a>
</body>
</html>