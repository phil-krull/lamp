<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Trip extends CI_Model 
{
  public function create($post)
    {
      $query= "INSERT INTO destinations (location, description, start, end, created_at, updated_at) VALUES (?,?,?,?, NOW(), NOW())";

      $values = array(
        $post['location'],
        $post['description'],
        $post['start'],
        $post['end'],
        );

      return $this->db->query($query, $values);
    }

  public function validate($post)
  {
    $this->form_validation->set_rules("location", "Location", "required");
    $this->form_validation->set_rules("description", "Description", "required");
    $this->form_validation->set_rules("start", "Travel Date From", "required");
    $this->form_validation->set_rules("end", "Travel Date To", "required");

    return $this->form_validation->run();
  }

  public function get_posted_trips()
  {
    $query = "SELECT location, description, start, end FROM destinations";
    return $this->db->query($query)->row_array();
  }
}