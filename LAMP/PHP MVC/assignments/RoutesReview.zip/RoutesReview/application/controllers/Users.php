<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends CI_Controller {


	public function index()
	{
		echo "Welome to the Users controller";
	}
	public function new_user()
	{
		echo "your reqister here";
	}
}