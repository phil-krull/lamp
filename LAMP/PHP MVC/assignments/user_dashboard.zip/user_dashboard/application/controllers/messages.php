<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class messages extends CI_Controller {

  public function __construct() {
    parent:: __construct();
    $this->load->model('message');
  }

  public function create($user_id) {
    $this->message->create($user_id, $this->session->userdata('id'), $this->input->post());
    redirect('/users/show/' . $user_id);
  }


}