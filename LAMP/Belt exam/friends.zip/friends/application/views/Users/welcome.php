<html>
<head>
  <title>Welcome</title>
</head>
<body>
  <p>Welcome</p>
  <a href="/users/new">Register</a>
  <a href="/sessions/new">Log in</a>
</body>
</html>