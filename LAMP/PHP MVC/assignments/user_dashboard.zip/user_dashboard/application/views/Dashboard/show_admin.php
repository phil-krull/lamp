<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>User Dashboard</title>
</head>
<body>
  <h3>Manage Users</h3>
  <form action="/sessions/destroy" method="post">
    <input type="submit" value="Logout">
  </form>
  <a href="/users/new">Add new</a>
  <table>
    <tr>
      <td>ID</td>
      <td>Name</td>
      <td>Email</td>
      <td>Register Date</td>
      <td>User Level</td>
      <td>Actions</td>
    </tr>
    <?php if($users) { ?>
      <?php foreach ($users as $key => $value) { ?>
      <tr>
        <td><?= $value['id'] ?></td>
        <td><a href="/users/show/<?= $value['id'] ?>"><?= $value['first_name'] ?> <?= $value['last_name'] ?></a></td>
        <td><?= $value['email'] ?></td>
        <td><?= date("M d, Y", strtotime($value['created_at'])) ?></td>
        <td><?= $value['user_level'] ?></td>
        <td><a href="/admins/edit/<?= $value['id'] ?>">Edit</a> | <a href="/admins/destroy/<?= $value['id'] ?>">Remove</a></td>
      </tr>
       <?php } ?>
    <?php } ?>
  </table>
  <? if ($this->session->flashdata('errors')) { ?>
    <?= $this->session->flashdata('errors') ?>
  <? } ?>
</body>
</html>