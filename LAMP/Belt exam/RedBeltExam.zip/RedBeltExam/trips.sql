-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema trips
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema trips
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `trips` DEFAULT CHARACTER SET utf8 ;
USE `trips` ;

-- -----------------------------------------------------
-- Table `trips`.`users`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trips`.`users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `username` VARCHAR(45) NULL,
  `password` VARCHAR(45) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `trips`.`destinations`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trips`.`destinations` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `location` VARCHAR(255) NULL,
  `description` VARCHAR(255) NULL,
  `start` DATETIME NULL,
  `end` DATETIME NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `trips`.`users_has_destinations`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trips`.`users_has_destinations` (
  `user_id` INT NOT NULL,
  `destination_id` INT NOT NULL,
  PRIMARY KEY (`user_id`, `destination_id`),
  INDEX `fk_users_has_destinations_destinations1_idx` (`destination_id` ASC),
  INDEX `fk_users_has_destinations_users_idx` (`user_id` ASC),
  CONSTRAINT `fk_users_has_destinations_users`
    FOREIGN KEY (`user_id`)
    REFERENCES `trips`.`users` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_has_destinations_destinations1`
    FOREIGN KEY (`destination_id`)
    REFERENCES `trips`.`destinations` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
