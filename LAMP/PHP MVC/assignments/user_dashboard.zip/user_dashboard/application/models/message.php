<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class message extends CI_Model {

  public function usershow($id) {
    $query = "SELECT messages.id, messages.user_id AS message_user_id, content AS message_content, users.first_name AS messager_first_name, users.last_name AS messager_last_name FROM messages JOIN users ON users.id = message_user_id WHERE user_id = ?";
    $values = array($id);

    return $this->db->query($query, $values)->result_array();
  }

  // public function show($id) {
  //   // $query = "SELECT * FROM messages WHERE user_id = ?";
  //   // $query = "SELECT messages.id, users.first_name, users.last_name, content, messages.created_at FROM messages JOIN users ON users.id = message_user_id WHERE messages.user_id = ?";
  //   $query = "SELECT messages.content, posts.content AS post_content, users.first_name, users.last_name, messages.created_at, post_user.first_name AS
  //       post_first_name, post_user.last_name AS post_last_name, posts.created_at AS post_created_at FROM messages
  //     JOIN users ON users.id = messages.message_user_id
  //     JOIN posts ON posts.message_id = messages.id
  //     JOIN users AS post_user ON post_user.id = posts.user_id
  //     WHERE messages.user_id = ?";

  //   $values = array($id);

  //   return $this->db->query($query, $values)->result_array();
  // }

  public function create($user_id, $messager_id, $post) {
    $query = "INSERT INTO messages (user_id, message_user_id, content, updated_at, created_at) VALUES (?,?,?,NOW(),NOW())";
    $values = array(
        $user_id,
        $messager_id,
        $post['content']
      );

    return $this->db->query($query, $values);
  }

}