<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class posts extends CI_Controller {

  public function __construct() {
    parent:: __construct();
    $this->load->model('post');
  }

  public function create($message_id, $message_user_id) {
    $this->post->create($message_id, $this->session->userdata('id'), $this->input->post());
    redirect('/users/show/' . $message_user_id);
  }


}