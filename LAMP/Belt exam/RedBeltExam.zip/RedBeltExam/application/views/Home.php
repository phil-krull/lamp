<html>
<head>
  <title>Travel Dashboard</title>
</head>
<body>
  <div id= "container">
    <form action= "/sessions/destroy" method= "post">
      <input type= "submit" value= "Logout">
    </form>
    <div id="main_content">
        <h1>Hello,</h1>
      <div id= "trip_schedules">
        <h2>Your Trip Schedules</h2>
        <table>
          <tr>
            <th>Destination</th>
            <th>Travel Start Date</th>
            <th>Travel End Date</th>
            <th>Plan</th>
          </tr>
        </table>
      </div><!--end of trip_schedules-->    
      <div id= "travel_plans">
        <h2>Other User's Travel Plans</h2>
        <table>
          <tr>
            <th>Name</th>
            <th>Destination</th>
            <th>Travel Start Date</th>
            <th>Travel End Date</th>
            <th>Do you want to join?</th>
          </tr>
        </table><br>
      </div><!--end of travel_plans-->
    </div><!--end of main_content-->
    <a href= "/trip/new">Add Travel Plan</a>
  </div><!--end of container-->
</body>
</html>