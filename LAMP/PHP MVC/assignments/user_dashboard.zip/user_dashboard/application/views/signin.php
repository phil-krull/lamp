<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
	<title>User Dashboard</title>
</head>
<body>
  <fieldset>
    <legend>Login</legend>
    <form action="/sessions" method="post">
      <table>
        <tr>
          <td>Email:</td>
          <td><input type="text" name="email"></td>
        </tr>
        <tr>
          <td>Password:</td>
          <td><input type="password" name="password"></td>
        </tr>
        <tr>
          <td></td>
          <td><input type="submit" value="Login"></td>
        </tr>
      </table>
    </form>
  </fieldset>
  <p>
    <? if ($this->session->flashdata('errors')) { ?>
      <?= $this->session->flashdata('errors') ?>
    <? } ?>
  </p>
  <a href="/register">Don't have an account? Register</a>
</body>
</html>