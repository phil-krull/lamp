<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$route['default_controller'] = 'surveys';
$route['404_override'] = '';
$route['process'] = 'surveys/process';
$route['process_form'] = 'surveys/process_form';
$route['return'] = 'surveys/return';


/* End of file routes.php */
/* Location: ./application/config/routes.php */