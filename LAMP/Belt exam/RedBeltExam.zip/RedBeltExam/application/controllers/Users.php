<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends CI_Controller {
  
  public function __construct()
  {
    parent::__construct();
    $this->load->model("User");
  }

  public function index()
  {
    $this->load->view("/Login");
  }

  public function create()
  {
    //Set up new user
    $this->load->library("form_validation");

    $validation_result = $this->User->validate($this->input->post());

    if ($validation_result == TRUE)
    {

    $this->User->create($this->input->post());

    redirect("/session/new");
    }
    else
    {
      $this->session->set_flashdata("errors", validation_errors());

      redirect("/");
    }
  }

  public function show()
  {
    $desired_designations = $this->Trip->get_posted_trips();

    $this->load->view('Trip', array('desired_designations'=> $desired_designations));
  }
}