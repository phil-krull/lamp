<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>User Dashboard</title>
</head>
<body>
  <a href="/users/edit">Profile</a> | <a href="/dashboard">Return to dashboard</a>
  <form action="/sessions/destroy" method="post">
    <input type="submit" value="Logout">
  </form>
  <h3>Edit Profile</h3>
  <fieldset>
    <legend>Edit Information</legend>
    <form action="/users/update/<?= $user['id'] ?>" method="post">
      <label>First Name:</label>
      <input type="text" name="first_name" value="<?= $user['first_name'] ?>">
      <label>Last Name:</label>
      <input type="text" name="last_name" value="<?= $user['last_name'] ?>">
      <label>Email:</label>
      <input type="email" name="email" value="<?= $user['email'] ?>">
      <input type="submit" value="Save">
    </form>
  </fieldset>
  <fieldset>
    <legend>Change Password</legend>
    <form action="/users/password_update/<?= $user['id'] ?>" method="post">
      <label>Password:</label>
      <input type="password" name="password">
      <label>Confirm Password:</label>
      <input type="password" name="password_confirmation">
      <input type="submit" value="Update Password">
    </form>
  </fieldset>
  <fieldset>
    <legend>Edit Description</legend>
    <form action="/users/update/<?= $user['id'] ?>" method="post">
      <textarea name="description"></textarea>
      <input type="submit" value="Save">
    </form>
  </fieldset>
  <? if ($this->session->flashdata('errors')) { ?>
    <?= $this->session->flashdata('errors') ?>
  <? } ?>
</body>
</html>