<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Trips extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->model("Trip");
  }

  public function index()
  {
    $this->load->view("/Trip");
  }

  public function create()
  {
    //trip destination to database
    $this->load->library("form_validation");

    $validation_result = $this->Trip->validate($this->input->post());

    if ($validation_result == TRUE)
    {

    $this->Trip->create($this->input->post());

    $destination = "You added you destination successfully";

    $this->session->set_flashdata("success", $destination);

    redirect("/trip/new");
    }
    else
    {
      $this->session->set_flashdata("errors", validation_errors());

      redirect("/trip/new");
    }
  }
}