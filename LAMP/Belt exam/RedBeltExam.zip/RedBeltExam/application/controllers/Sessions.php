<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sessions extends CI_Controller {

  public function index()
  {
    $this->load->view("/Home");
  }

  public function destroy()
  {
    $this->session->sess_destroy();
    redirect ('/');
  }
  public function update()
  {
    //
  }
}